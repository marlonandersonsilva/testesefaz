/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modelo;
public class Usuario {
    Long id;
    String nome;
    String email;
    String telefone;
    
    
    
    public String getemail() {
        return email;
    }
    public void setemail(String email) {
        this.email = email;

    }
    public Long getid() {
        return id;
    }
    public void setid(Long id) {
        this.id = id;
    } 
    public String getnome() { 
        return nome;
    } 
    public void setnome(String nome) { 
        this.nome = nome;
    } 
    public String gettelefone() { 
        return telefone;
    } 

    /**
     *
     * @param telefone
     */
    public void settelefone(String telefone) { 
        this.telefone = telefone;
    } 

}

